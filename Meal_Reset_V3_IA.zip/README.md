# Meal Reset V3 — IA
Servidor Node/Express + OpenAI Responses API.
Render: Build Command `npm install`; Start Command `npm start`.
Variable secreta: `OPENAI_API_KEY`.
No subas nunca una API key real a GitHub.
